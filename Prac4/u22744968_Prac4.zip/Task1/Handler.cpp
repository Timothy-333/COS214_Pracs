#include "Handler.h"

void Handler::handleRequest(Request request)
{
}