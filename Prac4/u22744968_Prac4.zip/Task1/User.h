#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

struct User
{
    string student_number;
    string private_key;
    string token;
};

#endif /* USER_H */
