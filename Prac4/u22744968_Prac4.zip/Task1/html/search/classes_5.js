var searchData=
[
  ['signinhandler_13',['SignInHandler',['../classSignInHandler.html',1,'']]]
];
