var searchData=
[
  ['authorizationhandler_8',['AuthorizationHandler',['../classAuthorizationHandler.html',1,'']]]
];
