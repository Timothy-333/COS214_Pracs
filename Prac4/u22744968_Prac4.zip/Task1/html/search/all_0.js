var searchData=
[
  ['authorizationhandler_0',['AuthorizationHandler',['../classAuthorizationHandler.html',1,'']]]
];
