var searchData=
[
  ['tokenvalidationhandler_14',['TokenValidationHandler',['../classTokenValidationHandler.html',1,'']]]
];
