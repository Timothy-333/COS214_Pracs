var searchData=
[
  ['signinhandler_5',['SignInHandler',['../classSignInHandler.html',1,'']]]
];
