#ifndef SQLADAPTEE_H
#define SQLADAPTEE_H
#include <string>
#include <iostream>
using namespace std;
class sqlAdaptee
{
    public:
        sqlAdaptee();
        string convertStringToPreCondition(string);
        
};
#endif