#include "target.h"
target::target()
{
}